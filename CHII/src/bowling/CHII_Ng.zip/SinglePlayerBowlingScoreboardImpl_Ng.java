// Authored by Jeffrey Ng
package bowling;

import java.util.stream.Collectors;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;


public class SinglePlayerBowlingScoreboardImpl_Ng implements SinglePlayerBowlingScoreboard, AssignmentMetaData {
	private static final int MAXIMUM_ROLLS = 21;    //Maximum rolls in a one player game
	private String playerName;
	private int[] pinsKnockedDownArray = new int[MAXIMUM_ROLLS];
	private int rollCount = 0;
	// private static final boolean DEBUGGING_FLAG = false;
	private static final String huh = "Something went wrong";

	private static final Set<Integer> validIntegers = new HashSet<>(Arrays.asList(0,1,2,3,4,5,6,7,8,9,10));
	private boolean classInvariantCheck() {
		boolean validPlayerName = playerName != null;
		boolean isSubSet = validIntegers.containsAll(Arrays.stream(pinsKnockedDownArray).boxed().collect(Collectors.toSet()));
		boolean rollCountInRange = 0 <= rollCount && rollCount <= MAXIMUM_ROLLS;
		return validPlayerName && isSubSet && rollCountInRange;
	}

	public SinglePlayerBowlingScoreboardImpl_Ng(String playerName) {
		assert playerName != null : "playerName is null!";
		this.playerName = playerName;
	}

	@Override
	public String getPlayerName() {
		assert classInvariantCheck();
		return playerName;
	}

	@Override
	public boolean isGameOver() {
		assert classInvariantCheck();

		boolean gameOver = false;
		int boxesFilled = getBoxesFilled();
		if (boxesFilled > 19) {
			int aux = rollCount - 2;
			int hold = pinsKnockedDownArray[aux];
			if (boxesFilled == 20 && hold != 10) {
				gameOver = true;
			}
			else if (boxesFilled == 21) {
				gameOver = true;
			}
		}

		assert classInvariantCheck();
		return gameOver;
	}

	/*
		Precondition(s):
							1 <= frameNumber <= 10
							getCurrentFrame > frameNumber

		Postcondition(s):
							Not sure yet
	*/
	@Override
	public int getScore(int frameNumber) {
		assert classInvariantCheck();

		assert 1 <= frameNumber && frameNumber <= 10;
		assert getCurrentFrame() > frameNumber;

		int endItr = frameNumToBoxTwoOfFrame(frameNumber);
		assert endItr % 2 == 1 : huh;
		int index = 0;
		int score = 0;
		while (index < endItr) {
			score += currFrameBoxesSum(index);
			if (isSpareByIndex(index)) {
				score += scoreSpare(index);
			}
			else if (isStrikeByIndex(index)) {
				score += scoreStrike(index);
				index--;
			}
			index += 2;
		}

		assert classInvariantCheck();
		return score;
	}
	private int currFrameBoxesSum(int index) { return pinsKnockedDownArray[index] + pinsKnockedDownArray[index + 1]; }
	private int scoreSpare(int index) { return pinsKnockedDownArray[index + 2]; }
	private int scoreStrike(int index) { return currFrameBoxesSum(index + 2); }
	private boolean isSpareByIndex(int index) { return pinsKnockedDownArray[index] + pinsKnockedDownArray[index + 1] == 10; }
	private boolean isStrikeByIndex(int index) { return pinsKnockedDownArray[index] == 10; }

	/*
		Precondition(s):
							1 <= frameNumber <= 10
							1 <= boxIndex <= 3
							when 1 <= frameNumber < 10, 1 <= boxIndex <= 2
		Postcondition(s):
							lol
	*/
	@Override
	public Mark getMark(int frameNumber, int boxIndex) {
		assert classInvariantCheck();

		assert 1 <= frameNumber && frameNumber <= 10;
		assert 1 <= boxIndex && boxIndex <= 3;
		assert frameNumber < 10  ? getCurrentFrame() >= frameNumber : true : getCurrentFrame() + "Lol" + frameNumber;
		assert frameNumber == 10 ? isGameOver() : true;
		assert frameNumber < 10  ? (1 <= boxIndex && boxIndex <= 2) : true;
		assert boxIndex == 3 ? frameNumber == 10 : true;

		Mark mark = naive(frameNumber, boxIndex);
//		Mark mark = ver2(frameNumber, boxIndex);

		assert classInvariantCheck();
		return mark;
	}

	private Mark ver2(int frameNumber, int boxIndex) {
		Mark mark = Mark.EMPTY;
		int itr = 0;
		int pinsArrayIndex = 0;
		boolean found = false;
		int endItr = frameNumber < 10 ? frameNumber * 2 : MAXIMUM_ROLLS;
		while (itr < endItr && !found) {
			int curFrame = itr / 2 + 1;
			found = curFrame == frameNumber;
			if (found && curFrame != 10) {
				int boxOne = pinsKnockedDownArray[pinsArrayIndex];
				int boxTwo = pinsKnockedDownArray[pinsArrayIndex + 1];
				if (isStrikeByIndex(pinsArrayIndex)) {
					mark = boxIndex == BOX_ONE ? Mark.EMPTY : Mark.STRIKE;
				}
				else if (isSpareByIndex(pinsArrayIndex)) {
					mark = boxIndex == BOX_ONE ? Mark.translate(boxOne) : Mark.SPARE;
				}
				else {
					mark = boxIndex == BOX_ONE ? Mark.translate(boxOne) : Mark.translate(boxTwo);
				}
			}
			else if (found && curFrame == 10) {

			}
			pinsArrayIndex++;
			if (isStrikeByIndex(pinsArrayIndex)) itr++;
			itr++;
		}

		return mark;
	}
	private Mark naive(int frameNumber, int boxIndex) {
		int[] boxVisual = new int[frameNumber < 10 ? frameNumber * 2: MAXIMUM_ROLLS];
		int offset = 0;
		for (int i = 0; i < boxVisual.length; i++) {
			int pinsArrayIndex = i - offset;
			if (isStrikeByIndex(i)) {
				boxVisual[i] = 0;
				boxVisual[i + 1] = pinsKnockedDownArray[pinsArrayIndex];
				offset++;
				i++;
			}
			else {
				boxVisual[i] = pinsKnockedDownArray[pinsArrayIndex];
			}
		}


		Mark mark = Mark.EMPTY;
		int firstBoxOfFrameIndex = (frameNumber - 1) * 2;
		int boxOnePins = boxVisual[firstBoxOfFrameIndex];
		int boxTwoPins = boxVisual[firstBoxOfFrameIndex + 1];

		if (boxOnePins == 10 || boxTwoPins == 10) {
			mark = boxIndex == BOX_ONE ? Mark.EMPTY : Mark.STRIKE;
		}
		else if (isSpareByIndex(firstBoxOfFrameIndex)) {
			mark = boxIndex == BOX_ONE ? Mark.translate(boxOnePins) : Mark.SPARE;
		}
		else {
			mark = boxIndex == BOX_ONE ? Mark.translate(boxOnePins) : Mark.translate(boxTwoPins);
		}

		return mark;
	}
	private int frameNumToBoxTwoOfFrame(int frameNumber) { return frameNumber * 2 - 1; }

	@Override
	public int getCurrentFrame() {
		assert classInvariantCheck();

		assert !isGameOver();

		int boxesFilled = getBoxesFilled();


		// Mark[] hold = new Mark[MAXIMUM_ROLLS];
		// for (int i = 0; i < MAXIMUM_ROLLS; i++) {
		// 	Mark curMark = Mark.translate(pinsKnockedDownArray[i]);
		// 	int frame = i / 2 + 1;
		// 	int boxIndex = (i % 2) + 1;
		// 	if (frame > 10) {
		// 		frame = 10;
		// 		boxIndex = 3;
		// 	}
		// 	System.out.println("Frame " + frame + " Box " + boxIndex + " " + curMark);
		// 	hold[i] = curMark;
		// }


		int rv = boxesFilled/2 + 1;
		assert classInvariantCheck();
		return rv;
	}

	private static final int BOX_ONE = 1, BOX_TWO = 2, BOX_THR = 3;
	@Override
	public int getCurrentBall() {
		assert classInvariantCheck();

		assert !isGameOver();

		int boxesFilled = getBoxesFilled();
		int currBall = 0;
		if (boxesFilled < 18) {
			currBall = boxesFilled % 2 == 0 ? BOX_ONE : BOX_TWO;
		}
		else {
			switch (boxesFilled) {
				case 18:
				currBall = BOX_ONE;
				break;
				case 19:
				currBall = BOX_TWO;
				break;
				case 20:
				currBall = BOX_THR;
				break;
			}
		}

		assert classInvariantCheck();
		return currBall;
	}

	/*
		Precondition(s):
							!isGameOver()
							0 <= pinsKnockedDown <= 10
							10 - prevRollPinsKnockedDown >= pinsKnockedDown
							rollCount <= 21
		Postcondition(s):
							Lol
	*/
	private static final int INITIAL_PIN_COUNT = 10;
	@Override
	public void recordRoll(int pinsKnockedDown) {
		assert classInvariantCheck();

		assert !isGameOver() : "Can't roll if game is over";
		assert rollCount <= MAXIMUM_ROLLS : "rollCount is out of bounds";
		assert 0 <= pinsKnockedDown && pinsKnockedDown <= INITIAL_PIN_COUNT : "pinsKnockedDown is out of bounrds";
		assert noOverflow(pinsKnockedDown) : "Cannot knock down more than a total of 10 pins";

		pinsKnockedDownArray[rollCount] = pinsKnockedDown;
		rollCount++;

		assert classInvariantCheck();
	}
	private boolean noOverflow(int pinsKnockedDown) {
		int boxesFilled = getBoxesFilled();
		if (boxesFilled == 19) {
			boxesFilled++;
		}
		int prevRollPinsKnockedDown = boxesFilled > 0 && boxesFilled % 2 == 1 ? pinsKnockedDownArray[rollCount - 1] : 0;

		return INITIAL_PIN_COUNT - prevRollPinsKnockedDown >= pinsKnockedDown;
	}

	private int getBoxesFilled() {
		int index = 0;
		int offset = rollCount;
		int boxesFilled = rollCount;
		while (index < rollCount && boxesFilled < 18) {
			if (isStrikeByIndex(index)) {
				offset--;
				boxesFilled++;
			}
			index++;
		}
//		boxesFilled += offset/2;

		return boxesFilled;
	}


	private static final String VERTICAL_SEPARATOR = "#";
	private static final String HORIZONTAL_SEPARATOR = "#";
	private static final String LEFT_EDGE_OF_SMALL_SQUARE = "[";
	private static final String RIGHT_EDGE_OF_SMALL_SQUARE = "]";
	private String getScoreboardDisplay() {
		StringBuffer frameNumberLineBuffer = new StringBuffer();
		StringBuffer markLineBuffer = new StringBuffer();
		StringBuffer horizontalRuleBuffer = new StringBuffer();
		StringBuffer scoreLineBuffer = new StringBuffer();
		frameNumberLineBuffer.append(VERTICAL_SEPARATOR);

		markLineBuffer.append(VERTICAL_SEPARATOR);
		horizontalRuleBuffer.append(VERTICAL_SEPARATOR);
		scoreLineBuffer.append(VERTICAL_SEPARATOR);

		for(int frameNumber = 1; frameNumber <= 9; frameNumber++)
		{
			frameNumberLineBuffer.append("  " + frameNumber + "  ");
			markLineBuffer.append(" ");
			markLineBuffer.append(getMark(frameNumber, 1));
			markLineBuffer.append(LEFT_EDGE_OF_SMALL_SQUARE);
			markLineBuffer.append(getMark(frameNumber, 2));
			markLineBuffer.append(RIGHT_EDGE_OF_SMALL_SQUARE);

			final int CHARACTER_WIDTH_SCORE_AREA = 5;
			for(int i = 0; i < CHARACTER_WIDTH_SCORE_AREA; i++) horizontalRuleBuffer.append(HORIZONTAL_SEPARATOR);
			if(isGameOver() || frameNumber < getCurrentFrame())
			{
				int score = getScore(frameNumber);
				final int PADDING_NEEDED_BEHIND_SCORE = 1;
				final int PADDING_NEEDED_IN_FRONT_OF_SCORE = CHARACTER_WIDTH_SCORE_AREA - ("" + score).length() - PADDING_NEEDED_BEHIND_SCORE;
				for(int i = 0; i < PADDING_NEEDED_IN_FRONT_OF_SCORE; i++) scoreLineBuffer.append(" ");
				scoreLineBuffer.append(score);
				for(int i = 0; i < PADDING_NEEDED_BEHIND_SCORE; i++) scoreLineBuffer.append(" ");
			}
			else
			{
				for(int i = 0; i < CHARACTER_WIDTH_SCORE_AREA; i++) scoreLineBuffer.append(" ");
			}

			frameNumberLineBuffer.append(VERTICAL_SEPARATOR);
			markLineBuffer.append(VERTICAL_SEPARATOR);
			horizontalRuleBuffer.append(VERTICAL_SEPARATOR);
			scoreLineBuffer.append(VERTICAL_SEPARATOR);
		}
		//Frame 10:
		{
			final String THREE_SPACES = "   ";
			frameNumberLineBuffer.append(THREE_SPACES + 10 + THREE_SPACES);

			markLineBuffer.append(" ");
			markLineBuffer.append(getMark(10, 1));
			markLineBuffer.append(LEFT_EDGE_OF_SMALL_SQUARE);
			markLineBuffer.append(getMark(10, 2));
			markLineBuffer.append(RIGHT_EDGE_OF_SMALL_SQUARE);
			markLineBuffer.append(LEFT_EDGE_OF_SMALL_SQUARE);
			markLineBuffer.append(getMark(10, 3));
			markLineBuffer.append(RIGHT_EDGE_OF_SMALL_SQUARE);

			final int CHARACTER_WIDTH_SCORE_AREA = 8;
			for(int i = 0; i < CHARACTER_WIDTH_SCORE_AREA; i++) horizontalRuleBuffer.append(HORIZONTAL_SEPARATOR);
			if(isGameOver())
			{
				int score = getScore(10);
				final int PADDING_NEEDED_BEHIND_SCORE = 1;
				final int PADDING_NEEDED_IN_FRONT_OF_SCORE = CHARACTER_WIDTH_SCORE_AREA - ("" + score).length() - PADDING_NEEDED_BEHIND_SCORE;
				for(int i = 0; i < PADDING_NEEDED_IN_FRONT_OF_SCORE; i++) scoreLineBuffer.append(" ");
				scoreLineBuffer.append(score);
				for(int i = 0; i < PADDING_NEEDED_BEHIND_SCORE; i++) scoreLineBuffer.append(" ");
			}
			else
			{
				for(int i = 0; i < CHARACTER_WIDTH_SCORE_AREA; i++) scoreLineBuffer.append(" ");
			}

			frameNumberLineBuffer.append(VERTICAL_SEPARATOR);
			markLineBuffer.append(VERTICAL_SEPARATOR);
			horizontalRuleBuffer.append(VERTICAL_SEPARATOR);
			scoreLineBuffer.append(VERTICAL_SEPARATOR);
		}

		return 	getPlayerName() + "\n" +
				horizontalRuleBuffer.toString() + "\n" +
				frameNumberLineBuffer.toString() + "\n" +
				horizontalRuleBuffer.toString() + "\n" +
				markLineBuffer.toString() + "\n" +
				scoreLineBuffer.toString() + "\n" +
				horizontalRuleBuffer.toString();
	}
	private String pinsArray() {
		StringBuilder sb = new StringBuilder();
		for (int curVal : pinsKnockedDownArray) {
			sb.append(curVal + " ");
		}
		return sb.toString();
	}
		private String myToString() {
			StringBuilder horizontalBuffer = new StringBuilder();
			StringBuilder frameNumber = new StringBuilder();
			StringBuilder boxes = new StringBuilder();
			StringBuilder frameScore = new StringBuilder();

			int offset = 0;
			Mark[] boxVersionMarks = new Mark[MAXIMUM_ROLLS];
			int[] boxVersionInts = new int[MAXIMUM_ROLLS];
			for (int frame = 0; frame < MAXIMUM_ROLLS; frame++) {
				int pinIndex =  frame - offset;
				Mark curMark = Mark.translate(pinsKnockedDownArray[pinIndex]);
				if (pinsKnockedDownArray[pinIndex] == 10) {
					boxVersionMarks[frame] = Mark.EMPTY;
					boxVersionMarks[frame + 1] = Mark.STRIKE;
					boxVersionInts[frame] = 0;
					boxVersionInts[frame + 1] = 10;
					offset++;
					frame++;
				}
				else {
					boxVersionMarks[frame] = curMark;
					boxVersionInts[frame] = pinsKnockedDownArray[pinIndex];
				}

			}

			int prevScore = 0;
			int score = 0;
			offset = 0;
			for (int frame = 0; frame < MAXIMUM_ROLLS - 3; frame+=2) {
				frameNumber.append(HORIZONTAL_SEPARATOR);
				frameNumber.append("   " + (frame / 2 + 1) + "   ");

				boxes.append(VERTICAL_SEPARATOR + LEFT_EDGE_OF_SMALL_SQUARE);
				boxes.append(boxVersionMarks[frame]);
				boxes.append(RIGHT_EDGE_OF_SMALL_SQUARE);

				boxes.append(VERTICAL_SEPARATOR + LEFT_EDGE_OF_SMALL_SQUARE);
				boxes.append(boxVersionMarks[frame + 1]);
				boxes.append(RIGHT_EDGE_OF_SMALL_SQUARE);

				frameScore.append(HORIZONTAL_SEPARATOR);
				score = prevScore + boxVersionInts[frame] + boxVersionInts[frame + 1];
				if (boxVersionInts[frame] + boxVersionInts[frame + 1] == 10 &&
					boxVersionInts[frame + 1] != 10) {
						if (boxVersionMarks[frame + 2] == Mark.EMPTY) {
							score += 10;
						}
						else {
							score += boxVersionInts[frame + 2];
						}
					}
				if (boxVersionInts[frame] + boxVersionInts[frame + 1] == 10 &&
					boxVersionInts[frame + 1] == 10) {
						if (boxVersionMarks[frame + 2] == Mark.EMPTY && boxVersionMarks[frame + 4] == Mark.EMPTY) {
							score += 20;
						}
						else if (boxVersionMarks[frame + 2] == Mark.EMPTY && boxVersionMarks[frame + 4] != Mark.EMPTY) {
							score += 10 + boxVersionInts[frame + 4];
						}
						else if (boxVersionMarks[frame + 2] != Mark.EMPTY) {
							score += boxVersionInts[frame + 2] + boxVersionInts[frame + 3];
						}
					}
				prevScore = score;
				switch (Integer.toString(score).length()) {
					case 3:
					frameScore.append("  " + score + "  ");
					break;

					case 2:
					frameScore.append("   " + score + "  ");
					break;

					case 1:
					frameScore.append("    " + score + "  ");
					break;
				}

				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
			}

			// tenth frame
			{
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				horizontalBuffer.append(HORIZONTAL_SEPARATOR);
				frameNumber.append(VERTICAL_SEPARATOR + "     "+ 10 + "    ");

				boxes.append(VERTICAL_SEPARATOR);
				boxes.append(LEFT_EDGE_OF_SMALL_SQUARE);
				boxes.append(boxVersionMarks[18]);
				boxes.append(RIGHT_EDGE_OF_SMALL_SQUARE);

				boxes.append(VERTICAL_SEPARATOR);
				boxes.append(LEFT_EDGE_OF_SMALL_SQUARE);
				boxes.append(boxVersionMarks[19]);
				boxes.append(RIGHT_EDGE_OF_SMALL_SQUARE);

				boxes.append(VERTICAL_SEPARATOR);
				boxes.append(LEFT_EDGE_OF_SMALL_SQUARE);
				boxes.append(boxVersionMarks[20]);
				boxes.append(RIGHT_EDGE_OF_SMALL_SQUARE);

				frameScore.append(VERTICAL_SEPARATOR);
				score = 0;
				switch (Integer.toString(score).length()) {
					case 3:
					frameScore.append("      " + score + "  ");
					break;

					case 2:
					frameScore.append("       " + score + "  ");
					break;

					case 1:
					frameScore.append("        " + score + "  ");
					break;
				}
			}

			frameNumber.append(VERTICAL_SEPARATOR);
			boxes.append(VERTICAL_SEPARATOR);
			horizontalBuffer.append(VERTICAL_SEPARATOR);
			frameScore.append(VERTICAL_SEPARATOR);

			return  getPlayerName() + ":\n" +
					horizontalBuffer.toString() + '\n' +
					frameNumber.toString() + '\n' +
					horizontalBuffer.toString() + '\n' +
					boxes.toString() + '\n' +
					horizontalBuffer.toString() + '\n' +
					frameScore.toString() + '\n' +
					horizontalBuffer.toString();
		}
	public String toString() {
		// return pinsArray();
		return myToString();
		// return getScoreboardDisplay();
		}
	@Override
	public String getFirstNameOfSubmitter() { return "Jeffrey"; }
	@Override
	public String getLastNameOfSubmitter() { return "Ng"; }
	@Override
	public double getHoursSpentWorkingOnThisAssignment() { return 23; }
	@Override
	public int getScoreAgainstTestCasesSubset() { return 16*5; }
}
