package census;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class WordCensusImpl_Ng implements WordCensus {
	private Map<String, Integer> wordCount;
	
	public WordCensusImpl_Ng(List<String> wordList) {
		Map<String, Integer> wordCountHash = new HashMap<>();
		wordList.forEach(word -> incrementCount(word, wordCountHash));

		wordCount = sortHashByValDescTheKeyAsc(wordCountHash);

		System.out.println(wordCount);

	}
	 
	@Override
	public int getCount(String word) {
		int count = 0;
		if (wordCount.containsKey(word)) {
			count = wordCount.get(word);
		}
		
		return count;
	}
	
	public String getWordWithRank(int i) {
		assert i > 0;

		Iterator<Map.Entry<String, Integer>> wordCountKeyItr = wordCount.entrySet().iterator();
		String wordWithRankI = null;
		int itr = 1;
		boolean found = false;
		while (wordCountKeyItr.hasNext() && !found) {
			wordWithRankI = wordCountKeyItr.next().getKey();
			found = itr == i;
			itr++;
		}
		
		return wordWithRankI;
	}

	public int getDistinctWordCount() {
		return wordCount.size();
	}

	private static final int JUST_ADDED = 1;
	private void incrementCount(String word, Map<String, Integer> wordCountHash) {
		if (wordCountHash.containsKey(word)) {
			int count = wordCountHash.get(word) + 1;
			wordCountHash.put(word, count);
		} else {
			wordCountHash.put(word, JUST_ADDED);
		}
	}

	private static Map<String, Integer> sortHashByValDescTheKeyAsc(Map<String, Integer> map) {
	    List<Map.Entry<String, Integer>> sortingList = new ArrayList<>(map.entrySet());

	    // Sort list by integer values then by string keys
	    Collections.sort(sortingList, (a, b) -> {
	        int cmp1 = b.getValue().compareTo(a.getValue());
	        if (cmp1 != 0)
	            return cmp1;
	        else
	            return a.getKey().compareTo(b.getKey());
	    });

	    Map<String, Integer> sortedHash = new LinkedHashMap<>();
	    for (Map.Entry<String, Integer> entry : sortingList)
	    	sortedHash.put(entry.getKey(), entry.getValue());

	    return sortedHash;
	}

}
